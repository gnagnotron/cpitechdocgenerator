import com.sap.it.api.mapping.*;

def String NumberWithZero(String num, String tot) {
    return num.padLeft(tot.toInteger(), '0')
}
