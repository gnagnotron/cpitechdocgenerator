<xsl:stylesheet version="1.0" 
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:target="http://www.skyminder.com/schema/skygtw"
    exclude-result-prefixes="target">

    <xsl:output method="xml" indent="yes" omit-xml-declaration="no"/>

    <xsl:template match="*">
        <xsl:element name="{local-name()}" namespace="http://www.skyminder.com/schema/skygtw">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>

    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>

    <xsl:template match="text() | comment() | processing-instruction()">
        <xsl:copy/>
    </xsl:template>
</xsl:stylesheet>