/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import groovy.time.TimeCategory;


def Message processData(Message message) {
    
    
    
    def now = new Date();
    use( TimeCategory ) {
        nowPlusFive = now + 1.minutes
    }
    def out_now = new SimpleDateFormat("yyyyMMdd HHmmss").format(nowPlusFive);
    
    
    def out_year = out_now.substring(0,4);  
    def out_month = out_now.substring(4,6);
    def out_day = out_now.substring(6,8);
    def out_date = out_year + "-" + out_month + "-" + out_day;
    def out_hour = out_now.substring(9,11);  
    def out_minutes = out_now.substring(11,13);
    def out_seconds = out_now.substring(13,15); 
    def out_time = out_hour + ":" + out_minutes + ":" + out_seconds;
    
    def output = out_date + "T" + out_time + "Z";
   
    message.setProperty("DATETIME_Next", output)
    return message;
}

