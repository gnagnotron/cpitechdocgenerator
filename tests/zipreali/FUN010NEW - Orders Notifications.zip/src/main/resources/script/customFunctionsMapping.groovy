import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import groovy.time.TimeCategory;
import com.sap.it.api.mapping.MappingContext

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/


def String getProperty(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String getHeader(String headerName, MappingContext context) {
    def headerValue = context.getHeader(headerName);
    return headerValue;
}

// 20211015T120024Z
/*  timestampType sarà
    - DATE
    - DATETIME
    - DATETIMEFAKE

*/
/**@
 * timestampType sarà
    - DATE
    - DATETIME
    - DATETIMEFAKE
 */
def String formatDate(String input, String timestampType) 
{
    
    // get substrings and create date and time
    def out_day = "01"

    def out_year = input.substring(0,4);  
    def out_month = input.substring(4,6);
    if(input.length() > 6)
    {
        out_day = input.substring(6,8); 
    }
    def out_date = out_year + "-" + out_month + "-" + out_day;
    def out_time;
    if(input.length() > 8)
    {
        def out_hour = input.substring(9,11);  
        def out_minutes = input.substring(11,13);
        def out_seconds = input.substring(13,15); 
        out_time = out_hour + ":" + out_minutes + ":" + out_seconds;
    }
    def out_hour_fake = "00"; 
    def out_minutes_fake = "00";
    def out_seconds_fake = "00";
    def out_time_fake = out_hour_fake + ":" + out_minutes_fake + ":" + out_seconds_fake;
    
    def output;
    
    if(timestampType == "DATE")
    {
        output = out_date;
    }
    if(timestampType == "DATETIME")
    {
        output = out_date + "T" + out_time + "Z";
    }
    if(timestampType == "DATETIMEFAKE")
    {
        output = out_date + "T" + out_time_fake + "Z";
    }
    
    
   
    return output;
}

// create time plus input

def String createDateTime(String input)
{
    
    def now = new Date();
    use( TimeCategory ) {
        nowPlusFive = now + 1.minutes
    }
    def formattedNowPlusFive = new SimpleDateFormat("yyyyMMdd HHmmss").format(nowPlusFive);
    
    
    def out_now = formatDate(formattedNowPlusFive, "DATETIME");
    
    return out_now;
}



def String getInitialsType(String input)
{
    def response = " "
    if(input.length() > 0)
    {
        def input_splitted = input.split("_")
        response = input_splitted[0].substring(0,1) + input_splitted[1].substring(0,1);
        return response;
    }
    else{
        return response;
    }
    
}

def String removeDecimals(String input)
{
    def output = "0"
    if(input.length() >= 3)
    {
        output = input.substring(0, input.length() - 3);
    }
    
    return output;
    
}

def String trimScoreValue(String input)
{
    if(input.length() > 10)
    {
        def splitted = input.split("-");
        def output = splitted[0].trim();
        return output;
    }
    else
    {
        return input;
    }
}















