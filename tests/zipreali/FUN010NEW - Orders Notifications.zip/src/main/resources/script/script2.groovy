import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
def Message processData(Message message) {
    //Body 
        def body = message.getBody(java.lang.String);
        def slurper = new JsonSlurper().parseText(body);
        
        // get request type and calculate 2 indexes
        def requestType = message.getProperty("REQUEST_Type");
        int firstSkycodeIndex;
        if(requestType == "initial")
        {
            firstSkycodeIndex = 0;
        }
        if(requestType == "step")
        {
            def REQUEST_Skycode_Step = message.getProperty("REQUEST_Skycode_Step");
            firstSkycodeIndex = slurper.root.order.findIndexOf{
                it.skycode == REQUEST_Skycode_Step
            }
        }
        
        
        // get first skycode and remove it from list
        def firstSkycode = slurper.root.order[firstSkycodeIndex].skycode;
        def firstUpdatedAt = slurper.root.order[firstSkycodeIndex].updatedAt;
        slurper.root.order.remove(slurper.root.order[firstSkycodeIndex]);
        message.setProperty("SKYCODE_Actual", firstSkycode);
        if(firstSkycode.length() > 17)
        {
            def skySplitted = firstSkycode.split("-");
            def firstSkyCodeOriginal = skySplitted[0];
            message.setProperty("SKYCODE_Actual_Original", firstSkyCodeOriginal);
        }
        else
        {
            message.setProperty("SKYCODE_Actual_Original", firstSkycode);   
        }
        message.setProperty("UPDATEDAT_Actual", firstUpdatedAt);
        
       
        // get second skycode if exists
        // i'll use the same index because I remove the first skycode
        if(slurper.root.order.size() > 0)
        {
            def secondSkycode = slurper.root.order[firstSkycodeIndex].skycode;
            def secondUpdatedAt = slurper.root.order[firstSkycodeIndex].updatedAt;
            message.setProperty("SKYCODE_Next", secondSkycode);
            message.setProperty("UPDATEDAT_Next", secondUpdatedAt);
           
        }
        
        // update output for update DataStore
        def jsonOutput = JsonOutput.toJson(slurper)
        message.setProperty("BODY_ToUpdate", jsonOutput);   


        message.setBody(jsonOutput)

        return message;
}