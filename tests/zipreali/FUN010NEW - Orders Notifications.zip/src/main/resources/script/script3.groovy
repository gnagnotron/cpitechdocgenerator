import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    
    // tolgo stringa da array vuoti
    body = body.replace('[""]', '[]')
    def input_json = new JsonSlurper().parseText(body); 
    
    // formatto sezione monitoring
    /*
    if(input_json.root.element[0].finalResult.monitorings[0] == "")
    {
        input_json.root.element[0].finalResult.remove(input_json.root.element[0].finalResult.monitorings)
    }
    */
    // Controlla se monitorings è vuoto o il primo elemento è una stringa vuota
    if (!input_json.root.element[0].finalResult.monitorings || 
    (input_json.root.element[0].finalResult.monitorings.size() > 0 && 
     input_json.root.element[0].finalResult.monitorings[0] instanceof String && 
     input_json.root.element[0].finalResult.monitorings[0].trim().isEmpty())) {
    
    // Rimuove la chiave "monitorings" dall'oggetto finalResult
    input_json.root.element[0].finalResult.remove("monitorings")

} else {
    // Se monitorings non è vuoto, riformatta i dati
    input_json.root.element[0].finalResult.monitorings[0] = input_json.root.element[0].finalResult.monitorings[0].element;
    Boolean isUnlimitedMonitoringTMP = input_json.root.element[0].finalResult.monitorings[0].isUnlimitedMonitoring as Boolean;
    input_json.root.element[0].finalResult.monitorings[0].isUnlimitedMonitoring = isUnlimitedMonitoringTMP;
}

    
    // formatto sezione changeNotifications
    input_json.root.element[0].finalResult.changeNotifications[0] = input_json.root.element[0].finalResult.changeNotifications[0].element;
    
    // formatto creditLimit
    //int creditLimitTMP = input_json.root.element[0].finalResult.creditReport.creditLimitAmount as int;
    //input_json.root.element[0].finalResult.creditReport.creditLimitAmount = creditLimitTMP;
    def creditLimitStr = input_json.root.element[0].finalResult.creditReport.creditLimitAmount
    def creditLimitTMP
    
    if (creditLimitStr == "") {
        creditLimitTMP = 0
    } else {
        creditLimitTMP = creditLimitStr.toFloat().toInteger()
    }
    input_json.root.element[0].finalResult.creditReport.creditLimitAmount = creditLimitTMP

    
    // formatto reportXML base64
    input_json.root.element[0].finalResult.creditReport.reportXML = input_json.root.element[0].finalResult.creditReport.reportXML.replace("\n", "");
    
    /* 
    def output_json = [];
    output_json[0] = input_json.root.element[0];
    if(input_json.root.elementIntermediate != null)
    {
        output_json[1] = input_json.root.elementIntermediate[0];

    }
    def jsonOutput = JsonOutput.toJson(output_json);
    message.setBody(jsonOutput)
    */
    
    // Inizializza una lista vuota
    def output_json = [];
    
    // Aggiungiamo il primo elemento
    if (input_json.root.element != null && input_json.root.element.size() > 0) {
        output_json.add(input_json.root.element[0]);
    }
    
    // Gestione elementIntermediate: rimosso l'indice [0] perché è un oggetto
    if (input_json.root.elementIntermediate != null) {
        output_json.add(input_json.root.elementIntermediate);
    }
    
    def jsonOutput = JsonOutput.toJson(output_json);
    message.setBody(jsonOutput);

    return message;
}