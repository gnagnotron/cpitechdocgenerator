/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {

       //body
        var body = message.getBody();
        body = JSON.parse(body);
        var headers = message.getHeaders();
        var properties = message.getProperties();
        var newBody = {
            "messageCode": "test",
            "messageText": "The provided monitoring productId is unknown"
            };
           

        
        try 
        {
            var errorCode = parseInt(headers.get("CamelHttpResponseCode"));
            if(errorCode == "500")
            {
                newBody.messageCode = errorCode;
                newBody.messageText = body.errors[0].details;      
                var isFullMonitoring = properties.get("isFullMonitoring");
                if(!isFullMonitoring)
                {
                    var result = properties.get("result");
                    result = JSON.parse(result);
                    //Rimuovo i monitorings
                    delete result.monitorings;
                    newBody = result;
                    message.setHeader("CamelHttpResponseCode", String(200));
                    message.setHeader("cai-additionalinformationtype", "INFO");
        message.setHeader("cai-additionalinformation", "OK");
                }
            }
            else
            {
                
                var result = properties.get("result");
                result = JSON.parse(result);
                // Imposto monitorings
                result.monitorings = [];
                result.monitorings.push(body[0]);
                newBody = result;
                message.setHeader("CamelHttpResponseCode", String(200));
                message.setHeader("cai-additionalinformationtype", "INFO");
        message.setHeader("cai-additionalinformation", "KO");
            }
            
            
        } catch (e) 
        {
            newBody.messageCode = String(500);
            newBody.messageText = "Internal Server Error";
            message.setHeader("cai-additionalinformationtype", "INFO");
        message.setHeader("cai-additionalinformation", "KO");
        }
        if(String(newBody.messageCode)[0] === "4")
            {
                var tmp = [];
                tmp.push(newBody);
                newBody = tmp;
                message.setHeader("cai-additionalinformationtype", "INFO");
        message.setHeader("cai-additionalinformation", "KO");
            }
        message.setBody(JSON.stringify(newBody));

        
     return message;
}