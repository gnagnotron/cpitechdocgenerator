import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String mapping(String arg1){
	switch(arg1) { 
        case "1":
            arg1 = "No risk / Very low risk";
            break;
        case "2":
            arg1 = "Low risk";
            break;
        case "3":
            arg1 = "Average risk";
            break;
        case "4":
            arg1 = "Above average risk";
            break;
        case "5":
            arg1 = "High risk";
            break;
        case "UN":
            arg1 = "Unknown";
            break;
    default:
        arg1 = "Unknown";
    } 
    return arg1;
}