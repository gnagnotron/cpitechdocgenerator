/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
       //body
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    
    var properties = message.getProperties();
    var payload_tmp = properties.get("tmp_output");
    payload_tmp = JSON.parse(payload_tmp);
    function replaceAll(str, cerca, sostituisci) {
        return str.split(cerca).join(sostituisci);
    }
      
    var productCodeResponse = payload.product.name;
    payload_tmp.productCode = replaceAll(productCodeResponse, " ", "").toUpperCase() + "FM";
    //payload_tmp = JSON.stringify(payload_tmp);
    var array=[];
    array.push(payload_tmp);
    message.setBody(JSON.stringify(array));
    //message.setBody(JSON.stringify(payload_tmp));
    
    
     return message;
}