/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    //body
    var body = message.getBody();
    //body
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    
    properties = message.getProperties();
    //var resultStep3 = properties.get("resultStep3");
    
    //MAPPING DEI RISULTATI da mettere nel result
    //Creo la struttura
    var xml = properties.get("xmlTest");
    var obj = {
        companyId: "",
        orderId: "",
        orderStatus": "",
        orderMessage": "",
        creditReport": {
            reportId": "",
            productCode": "",
            companyName": "",
            companyFoundationDate": "",
            legalFormCode": "",
            legalFormDescription": "",
            industrySectorCode": "",
            industrySectorName": "",
            creditLimitAmount": ,
            creditLimitCurrencyISO": "",
            creditRatingCode": "",
            creditRatingDescription": "",
            creditRatingScore": [
                {
                    "scoreTypeCode": "",
                    "scoreValue": 
                }
            ],
            creditRatingValidityDateTimeUTC": "",
            reportXML": "",
            reportPDF": ""
        },
        monitorings": [
            {
                activationId: """,
                productCode: "",
                parentProductCode: "",
                startOfMonitoringDateTimeUTC: "",
                endOfMonitoringDateTimeUTC: "",
                isUnlimitedMonitoring: "",
                activationStatus: "",
                activationStatusDescription: "",
                lastChangeDateTimeUTC: ""
            }
        ]
    }
    //obj.creditReport.reportXML = xmlTest.toString();
    obj.creditReport.reportXML = "prova";
    message.setBody(obj);
    return message;
}