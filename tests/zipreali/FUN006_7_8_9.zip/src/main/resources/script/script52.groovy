/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.lang.*;
def Message processData(Message message) {

    def displayMaps = { String mapName, Map map ->
		StringBuilder sb = new StringBuilder()
		sb.append(mapName).append("\n")
		map.each { key, value -> sb.append(key).append(" = ").append(value).append("\n")  }
		return sb.toString()
	}
	
    def headers = displayMaps("##Headers:", message.getHeaders())
    def properties = displayMaps("##Properties:", message.getProperties())
    
    StringBuilder sb = new StringBuilder()
	def body = message.getBody(java.lang.String) as String;
	for (int i = 0; i < body.length(); i++) {
	    if (i > 0 && (i % 200 == 0)) {
	        sb.append("\n");
	    }
	
	    sb.append(body.charAt(i));
	}
	body = sb.toString();
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("10 - FUN007 XML to JSON", "### BODY ### \n" + body + "\n ### HEADERS ### \n" + headers + "\n ### PROPERTIES ### \n" + properties, "text/plain");
        
    
     }
    return message;
    
    
    
}