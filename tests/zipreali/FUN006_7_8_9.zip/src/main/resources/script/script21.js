/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) 
{
    
        // FUNCTIONS
    /*
    function formatDate(a)
    {
        a = a.slice(0,4) + "-" + a.slice(4,a.length);
        a = a.slice(0,7) + "-" + a.slice(7, a.length);
        a = a.slice(0,13) + ":" + a.slice(13, a.length);
        a = a.slice(0,16) + ":" + a.slice(16, a.length);    
        return a;
    }
    */
    function formatDate(a, isDateTime)
    {
        a = a.slice(0,4) + "-" + a.slice(4,a.length);
        a = a.slice(0,7) + "-" + a.slice(7, a.length);
        if(isDateTime)
        {
            a = a.slice(0,13) + ":" + a.slice(13, a.length);
            a = a.slice(0,16) + ":" + a.slice(16, a.length); 
        }
        else
        {
            a = a.split("T")[0];
        }
        return a
        
    }
    var body = message.getBody();
    var properties = message.getProperties();
    var productCode = properties.get("productCode");
    var inputStream = new java.io.InputStreamReader(body);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    body = payload;
    
    //Proprietà
    var properties = message.getProperties();
    var result = properties.get("result");
    result = JSON.parse(result);
    //Rimuovo i monitorings
    delete result.monitorings;
    result.monitorings = [];    //Aggiungo un array di monitorings
    if(body.status === "ACTIVE")
    {
        body.status = "ACTIVATED";
    }
    var obj = {
        //se non funziona provare: activationId: "" + body.monitoringId;
        "activationId": String(body.monitoringId),   
        //"productCode": "" + result.creditReport.reportId,
        "productCode": "" + productCode,
        //"parentProductCode": "" + result.creditReport.reportId,
        "monitoringStartDate": "" + formatDate(body.registeredAt, false),
        "monitoringEndDate": "" + formatDate(body.renewedAt, false),
        "isUnlimitedMonitoring": true,
        //"activationStatus": "" + body.status
    }
    result.monitorings.push(obj);
    
    // var array = [];
    // array.push(result.creditReport.creditRatingScore);
    // result.creditReport.creditRatingScore = array;
    
    result = JSON.stringify(result);
    
    //message.setBody(JSON.stringify(result));
    message.setBody(result);
    return message;
}