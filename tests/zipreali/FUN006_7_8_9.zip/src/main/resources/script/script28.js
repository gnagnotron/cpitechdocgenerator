/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getproperties()
    public void setproperties(java.util.Map<java.lang.String,java.lang.Object> exchangeproperties)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {

       //body
        var body = message.getBody();
        body = JSON.parse(body);
        var properties = message.getProperties();      
        var newBody = {
            "messageCode": "test",
            "messageText": "The provided monitoring productId is unknown"
            };
           
        try 
        {
            var errorCode = parseInt(properties.get("http.StatusCode"));
            var errorText = body.errors[0].details;
            
            message.setHeader("cai-additionalinformationtype", "INFO");
            message.setHeader("cai-additionalinformation", "KO");
            if(errorCode == 500 && errorText == "Renewal date is bigger than 30 days")
            {
                var newBody = {};
                newBody.messageCode = "400";
                newBody.messageText = "Monitoring can not be disabled: renewal date is bigger than 30 days";
                message.setHeader("CamelHttpResponseCode", String(400));
                var tmp = [];
                tmp.push(newBody);
                newBody = tmp;
            }
            else{
                var newBody = {};
                newBody.messageCode = errorCode;
                newBody.messageText = errorText;
            }
            
        } catch (e) 
        {
            newBody.messageCode = String(500);
            newBody.messageText = "Internal Server Error";
                        message.setHeader("CamelHttpResponseCode", "500");
                        
                        message.setHeader("cai-additionalinformationtype", "INFO");
                        message.setHeader("cai-additionalinformation", "KO");

        }
        if(String(newBody.messageCode)[0] === "4")
            {
                var tmp = [];
                tmp.push(newBody);
                newBody = tmp;
                message.setHeader("cai-additionalinformationtype", "INFO");
                message.setHeader("cai-additionalinformation", "KO");
            }
        message.setHeader("cai-additionalinformationtype", "INFO");
        message.setHeader("cai-additionalinformation", "KO");    
        message.setBody(JSON.stringify(newBody));

        
     return message;
}