/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    
    var properties = message.getProperties();
    var resultStep1 = properties.get("resultStep1");
    var resultStep2 = properties.get("resultStep2");
    //var resultStep3 = properties.get("resultStep3");
    
    //Creo la struttura finale 
    var obj = {
        companyId: "",
        orderId: "",
        orderStatus: "FULLFILLED",
        orderMessage: "",
        creditReport: {
            reportId: "",
            productCode: "",
            companyName: "",
            companyFoundationDate: "",
            legalFormDescription: "",
            industrySectorCode: "",
            industrySectorName: "",
            creditLimitAmount: "",
            creditLimitCurrencyISO: "",
            creditRatingCode: "",
            creditRatingDescription: "",
            creditRatingScore: [
                {
                    scoreTypeCode: "",
                    scoreValue: ""
                }
            ],
            creditRatingValidityDateTimeUTC: "",
            reportXML: "XXX",
            reportPDF: "XXX"
        },
        monitorings: [
            {
                activationId: "",
                productCode: "",
                parentProductCode: "",
                startOfMonitoringDateTimeUTC: "",
                endOfMonitoringDateTimeUTC: "",
                isUnlimitedMonitoring: false,
                activationStatus: "",
                activationStatusDescription: ""
            }
        ]
    }
    //STEP 1: 
    obj.creditReport.productCode = resultStep1.skycode;
    for(var i=0; i<obj.monitorings.length;i++)
    {
        obj.monitorings[i].productCode = resultStep1.skycode;
    }
    
    //STEP 2: 
    obj.companyId = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.OrderDetails.Identifier.IDNumber;
    obj.orderId = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.OrderDetails.DocumentID;
    obj.orderMessage = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.OrderDetails.DeliveryStatus;
    obj.creditReport.reportId = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.OrderDetails.DocumentID;
    obj.creditReport.companyName = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.CompanyName;
    obj.creditReport.companyFoundationDate = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.RegistrationDate;
    obj.creditReport.legalFormCode = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.LegalFormCode;
    obj.creditReport.legalFormDescription = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.LegalFormDescription;
    //obj.creditReport.industrySectorCode = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.NormalizedPrimaryIndustry.Code;
    /*
    obj.creditReport.industrySectorName = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.NormalizedPrimaryIndustry.Description;
    obj.creditReport.creditLimitAmount = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.RiskData.CreditLimit.Amount;
    obj.creditReport.creditLimitCurrencyISO = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.RiskData.CreditLimit.Currency;
    obj.creditReport.creditRatingCode = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.RiskData.RatingName;
    obj.creditReport.creditRatingDescription = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.RiskData.RatingDescription;
    obj.creditReport.creditRatingScore.scoreTypeCode = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.RiskData.RatingName;
    obj.creditReport.creditRatingScore.scoreValue = resultStep2.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.BusinessHighlights.RiskData.RatingValue;
    */
    var xmlFile = properties.get("xmlFile");
    xmlFile = JSON.parse(xmlFile);
    var xml = xmlFile.reportXML;
    var tmp = xml.substring(0,xml.indexOf("<Sections>"));
    var tmp2 = xml.substring(xml.indexOf("</Sections>") + "</Sections>".length, xml.length);
    var base = xml.substring(xml.indexOf("<SectionContent>") + "<SectionContent>".length, xml.indexOf("</SectionContent>"));
    obj.creditReport.reportPDF = base;
    obj.creditReport.reportXML= tmp + tmp2;
    message.setProperty("bodyTemp", JSON.stringify(obj));

    //message.setBody(JSON.stringify(obj));
    return message;
}