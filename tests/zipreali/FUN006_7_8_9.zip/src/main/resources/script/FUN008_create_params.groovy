/*import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def countryCode = message.getProperty("countryCode")
    def SKYMINDER_CompanyName = message.getProperty("SKYMINDER_CompanyName")
    def params
    if(SKYMINDER_CompanyName == '' || SKYMINDER_CompanyName == null)
    {
        params = "address.countryCode="+ countryCode;
    }
    else
    {
        params = "company.name=" + SKYMINDER_CompanyName +"&address.countryCode=" + countryCode
    }
    
    message.setProperty("params", params)
    return message;
}
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.net.URLEncoder;
import java.util.HashMap;

def Message processData(Message message) {
    
    def countryCode = message.getProperty("countryCode")
    def SKYMINDER_CompanyName = message.getProperty("SKYMINDER_CompanyName")
    def params
    if(SKYMINDER_CompanyName == '' || SKYMINDER_CompanyName == null)
    {
        params = "address.countryCode="+ URLEncoder.encode(countryCode, "UTF-8");
    }
    else
    {
        params = "company.name=" + URLEncoder.encode(SKYMINDER_CompanyName, "UTF-8") + "&address.countryCode=" + URLEncoder.encode(countryCode, "UTF-8");
    }
    
    message.setProperty("params", params)
    return message;
}
