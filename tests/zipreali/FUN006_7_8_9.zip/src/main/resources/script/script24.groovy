/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlParser;

def Message processData(Message message) 
{
    def body = message.getBody(java.lang.String) as String;
    def rootNode = new XmlParser().parseText(body);
//    def deliveryStatus = rootNode.GetMyReportDocumentResponse.GetMyReportDocumentDetail.Result.OrderDetails.DeliveryStatus.text();
    def deliveryStatus = rootNode.GetMyReportDocumentDetail.Result.OrderDetails.DeliveryStatus;
    
    def stringaele = (String)deliveryStatus.get(0);
    
    if(stringaele.indexOf("Delivered") != -1)
    {
        message.setProperty("DeliveryStatus", "Delivered");
    }
    return message;
}