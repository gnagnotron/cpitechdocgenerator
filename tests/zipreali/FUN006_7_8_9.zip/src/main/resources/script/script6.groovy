/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.xml.XmlUtil;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    
    //Prendo il pdf
    def tmp1 = body.indexOf("<SectionContent>")
    def tmp2 = body.indexOf("</SectionContent>");
    if(tmp1 != -1 && tmp2 != -1)
    {
        def pdf = body.substring(tmp1 + "<SectionContent>".length(), tmp2);
        //Prendo l'xml
        def sub1 = body.substring(0, body.indexOf("<Sections>"));
        def sub2 = body.substring(body.indexOf("</Sections>") + "</Sections>".length(), body.length());
        def xml = sub1 + sub2;
        xml = xml.bytes.encodeBase64().toString();
        message.setProperty("xml", xml);
        message.setProperty("pdf", pdf);
    }
    else{
        message.setProperty("xml", "");
        message.setProperty("pdf", "");
    }
    
    
    
    return message;
}