importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    
    // properties
    var map = message.getProperties();
    var companyId = map.get("companyId");
    
    // headers
    var headers = message.getHeaders();
    var countryCode = headers.get("cai-countrycodeiso");
    
    // generate parameters
    var params = "countryCode=" + countryCode + "&company.supplierId="+ companyId;
    params = params + "&type=ONLINE"
    message.setProperty("params", params);
    return message;
}