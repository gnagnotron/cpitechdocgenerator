import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String formatDate(String a){
    a = a.substring(0,4) + "-" + a.substring(4,a.length());
    a = a.substring(0,7) + "-" + a.substring(7, a.length());
    if(a.length() < 9)
    {
        a = a + "01";
    }
	return a;
}

def String formatDateTime(String a)
{
    a = a.substring(0,4) + "-" + a.substring(4,a.length());
    a = a.substring(0,7) + "-" + a.substring(7, a.length());
    a = a.substring(0,13) + ":" + a.substring(13, a.length());
    a = a.substring(0,16) + ":" + a.substring(16, a.length());

}
def String formatDateFakeTime(String a){
    def lunghezza = a.length();
    
    if(lunghezza > 4)
    {
            a = a.substring(0,4) + "-" + a.substring(4,a.length());
            a = a.substring(0,7) + "-" + a.substring(7, a.length());
    }
    if(lunghezza == 4)
    {
        a = a + "-01-01";
    }
    
    
    a = a + "T00:00:00Z";
	return a;
}