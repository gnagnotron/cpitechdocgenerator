/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
def Message processData(Message message) {
    
    //Headers 
    def map = message.getProperties();
    def user = map.get("SkyUser");
    def pass = map.get("SkyPass");  
    // split to get credentials from header   

    String concat = user + ":" + pass;
    String encoded = concat.bytes.encodeBase64().toString();
    
    message.setHeader("Authorization", "Basic QUxURUFfQTJBMDAxOnpIeGojNTIzMg==");
    message.setProperty("Authorization", "Basic " + encoded);
    message.setHeader("Accept", "application/vnd.skyminder.api.v1+json");
    message.setProperty("url","https://testa2a.skyminder.com/sky-rest-service");
       
    return message;
}