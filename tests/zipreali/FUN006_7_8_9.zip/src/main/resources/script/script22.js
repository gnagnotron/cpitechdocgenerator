/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    
    // FUNCTIONS
    
    function formatDate(a, isDateTime)
    {
        a = a.slice(0,4) + "-" + a.slice(4,a.length);
        a = a.slice(0,7) + "-" + a.slice(7, a.length);
        if(isDateTime)
        {
            a = a.slice(0,13) + ":" + a.slice(13, a.length);
            a = a.slice(0,16) + ":" + a.slice(16, a.length); 
        }
        else
        {
            a = a.split("T")[0];
        }
        return a
        
    }
    //body
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    
    //Creo la struttura
    var array = [];
    var obj = {
        "activationId": "",
        "productCode": "",
        //"parentProductCode": "",
        "monitoringStartDate": "",
        "monitoringEndDate": "",
        "isUnlimitedMonitoring": false
        //"activationStatus": "",
        //"activationStatusDescription": "",
        //"lastChangeDateTimeUTC": ""
    }
    array.push(obj);
    
    obj.activationId = String(payload.monitoringId);
    obj.productCode = payload.skycode;          
    obj.monitoringStartDate = formatDate(payload.registeredAt, false);
    obj.monitoringEndDate = formatDate(payload.renewedAt, false);
    //obj.activationStatus =  payload.status;
    /*
    if(payload.status === "INACTIVE")
    {
        obj.activationStatus = "CANCELLATION_REQUESTED";
    }
    else
    {
        obj.activationStatus =  payload.status;
    }
    */
    if(typeof(payload.updatedAt) === "string")
    {
        obj.lastChangeDateTimeUTC = formatDate(payload.updatedAt, true);
    }
    
    message.setBody(JSON.stringify(obj));
    message.setProperty("tmp_output", JSON.stringify(obj));
    message.setProperty("tmp_skycode", payload.skycode);
    
    return message;
}