/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) 
{
    //Body
    var body = message.getBody();
    
    var payload = JSON.parse(body);
    //Proprietà
    var properties = message.getProperties();
    var result = properties.get("result");
    result = JSON.parse(result);
    //Rimuovo i monitorings
    delete result.monitorings;
    result = JSON.stringify(result);
    
    //message.setBody(JSON.stringify(result));
    message.setBody(result);
    return message;
}