/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(java.nio.charset.StandardCharsets);

function processData(message) {
    
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body, StandardCharsets.UTF_8);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    var properties = message.getProperties();
    var productCode = properties.get("productCode");

    for(var i = 0; i < payload.length; i++)
    {
        if(productCode == payload[i].productCode)
        {
            productCode = payload[i].productName;
        }
    }
       var orderType = properties.get("orderType");
       var reference = properties.get("reference");
       var language = properties.get("language");
       var identifiersType = properties.get("identifiersType");
       var companyId = properties.get("companyId");
       
       var headers = message.getHeaders();
       var countryCode = headers.get("cai-countrycodeiso");
       
       
       var newBody = {
            "orderInformation": {
    	"userReference": ""
        },
           "language":"",
           "company":{
              "addresses":[
                 {
                    "countryCode":""
                 }
              ],
              "identifiers":[
                 {
                    "type":"",
                    "number":""
                 }
              ]
           },
           "product":{
              "code":""
           }
        };

        
        
        newBody.language = String(language);
        newBody.company.addresses[0].countryCode = String(countryCode);
        newBody.company.identifiers[0].type = String(identifiersType);
        newBody.company.identifiers[0].number = String(companyId);
        newBody.product.code = String(productCode);
        
        
        if(String(reference) === "null" )
        {
            delete newBody.orderInformation.userReference;
        }
        else
        {
            newBody.orderInformation.userReference = String(reference);
        }
        if(String(newBody.orderInformation.userReference) === "undefined")
        {
            delete newBody.orderInformation.userReference;
        }
    // NO TEST
    switch (String(countryCode)) {
        case 'DEU':
            newBody.orderInformation = {"proofOfInterest": "CREDIT_DECISION"};
            break;
        case 'USA':
            newBody.orderInformation = {"proofOfInterest": "CREDITOR_FINANCIAL_TRANSACTION_CONNECTION"};
        default:
        
    }
       
        var newBody = JSON.stringify(newBody);
        message.setBody(newBody);
     return message;
}