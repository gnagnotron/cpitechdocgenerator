/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(java.nio.charset.StandardCharsets);

function processData(message) {
    //body
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body, StandardCharsets.UTF_8);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    result = payload.root;
    function replaceAll(str, cerca, sostituisci) {
        return str.split(cerca).join(sostituisci);
    }
    /*
    var array = [];
    array.push(result.creditReport.creditRatingScore);
    if(array[0] === "")
    {
            array = [];

    }
    */
    result.creditReport.creditLimitAmount = parseInt(result.creditReport.creditLimitAmount);
    //result.creditReport.creditRatingScore = array;
    // Se il primo elemento dell'array è una stringa vuota, svuota l'array
    if (result.creditReport.creditRatingScore[0] === "") {
        result.creditReport.creditRatingScore = [];
    }
    
    result.creditReport.reportXML = replaceAll(result.creditReport.reportXML, '\"','\'');
    message.setProperty("test", result.creditReport.reportXML);
    message.setProperty("result", JSON.stringify(result));
    message.setBody(JSON.stringify(result));
    return message;
}