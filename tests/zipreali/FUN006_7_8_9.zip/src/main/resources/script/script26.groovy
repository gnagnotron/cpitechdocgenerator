/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

                // get a map of iflow properties
                def map = message.getProperties();

                // get an exception java class instance
                def ex = map.get("CamelExceptionCaught");
                if (ex!=null)
                {

              // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
                    if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException"))
                    {

                    // save the http error response as a message attachment 
                    def messageLog = messageLogFactory.getMessageLog(message);
                    messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

                    // copy the http error response to an iflow's property
                    message.setProperty("http.ResponseBody",ex.getResponseBody());

                    // copy the http error response to the message body
                    message.setBody(ex.getResponseBody());

                    // copy the value of http error code (i.e. 500) to a property
                    message.setProperty("http.StatusCode",ex.getStatusCode());

                    // copy the value of http error text (i.e. "Internal Server Error") to a property
                    message.setProperty("http.StatusText",ex.getStatusText());

                    }
                }

    return message;
}