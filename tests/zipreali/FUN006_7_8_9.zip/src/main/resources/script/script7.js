/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(java.nio.charset.StandardCharsets);

function processData(message) {
    //body
    var body = message.getBody();
	var inputStream = new java.io.InputStreamReader(body, StandardCharsets.UTF_8);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);
    
function replaceAll(str, cerca, sostituisci) {
    return str.split(cerca).join(sostituisci);
}
  
  
  
//Dichiaro la struttura
var array = [];
var obj = {
    productCode: "",
    productName: "",
    availableLanguagesISO: ""
}
//Riempio la struttura
for(var i=0;i<payload.products.length;i++)
{
    obj={};
    obj.productCode = replaceAll(payload.products[i].name, " ", "").toUpperCase();
    obj.productName = payload.products[i].name;
    obj.availableLanguagesISO = payload.products[i].languages;
    for(var j=0;j<obj.availableLanguagesISO.length;j++)
    {
        obj.availableLanguagesISO[j] = obj.availableLanguagesISO[j].toUpperCase();
    }
    for(var j = 0; j < payload.products[i].monitoringProducts.length; j++)
    {

        if(payload.products[i].monitoringProducts[j].name === "Full Monitoring")
        {

            var tmp = JSON.parse(JSON.stringify(obj));
            tmp.productCode = tmp.productCode + "FM";
            tmp.productName = tmp.productName + " with Monitoring";
            array.push(tmp);
        }
        if(payload.products[i].monitoringProducts[j].type === "PLANNED_REVISION")
        {
            var tmp = JSON.parse(JSON.stringify(obj));
            tmp.productCode = tmp.productCode + "PR";
            tmp.productName = tmp.productName + " with Planned Revision";
            array.push(tmp);
        }
        
}

//Pusho l'oggetto nell'array;
array.push(obj);
}

var tmp = [];
    for(var j = 0; j < array.length; j++)
        {
            if(tmp.length == 0)
            {
                tmp.push(array[j]);
            }
            else
            {
                var nuovo = true;
                for(var i = 0; i < tmp.length; i++)
                {
                    if(tmp[i].productCode == array[j].productCode)
                    {
                        nuovo = false;
                        continue;
                        
                    }
                    else
                    {
                        if(nuovo && i == tmp.length - 1)
                        {
                            tmp.push(array[j]);
                        }
                        
                    }
                }
            }
            
    }    
    message.setBody(JSON.stringify(tmp));
    return message;
}

