/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import groovy.json.*

def Message processData(Message message) {

	
	def body = message.getBody(java.lang.String) as String;
		
	//Headers 
    def map = message.getHeaders();
    def value = map.get("cai-credentials");
    def pass = "password=".toString()
	def user = "logonusername=".toString()
	def password;
	def username;
	def array = value.split(",")
	if(array[0].indexOf("password=") == 0)
	{
		password = array[0].substring(array[0].indexOf(pass) + pass.length(), array[0].length());
		username = array[1].substring(array[1].indexOf(user) + user.length(), array[1].length())
	}
	else
	{
		username = array[0].substring(array[0].indexOf(user) + user.length(), array[0].length());
		password = array[1].substring(array[1].indexOf(pass) + pass.length(), array[1].length())
	}
    message.setProperty("SkyUser", username);
    message.setProperty("SkyPass", password);
		
		
		if(body != "")
		{
		    def jsonSlurper = new JsonSlurper();
            def object = jsonSlurper.parseText(body);
            assert object instanceof Map;
            
            def jsonOutput = new JsonOutput();
            body = jsonOutput.toJson(object);
            message.setBody(body);    
		}
		
	
	
	return message;
}