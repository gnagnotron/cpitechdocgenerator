/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {

       //body
        var body = message.getBody();
        
        var headers = message.getHeaders();
        var newBody = {
            "messageCode": "test",
            "messageText": "The provided monitoring productId is unknown"
            };
           
        message.setHeader("cai-additionalinformationtype", "INFO");
        message.setHeader("cai-additionalinformation", "KO");
        try 
        {
            body = JSON.parse(body);
            var errorCode = parseInt(headers.get("CamelHttpResponseCode"));
            newBody.messageCode = errorCode;
            newBody.messageText = body.errors[0].details;
            var properties = message.getProperties();
            var errore = properties.get("error");
            if(String(errore) === "nomonitoring")
            {
                //newBody.messageCode = String(400);
                //newBody.messageText = "No monitoring found";
                //message.setHeader("CamelHttpResponseCode", "400");
                var result = properties.get("result");
                if(result !== null)
                {
                    result = JSON.parse(result);
                    //Rimuovo i monitorings
                    delete result.monitorings;
                    message.setHeader("CamelHttpResponseCode", "200");
                    message.setBody(JSON.stringify(result));
                    return message;
                }
            }


        } catch (e) 
        {
            newBody.messageCode = String(500);
            newBody.messageText = "Internal Server Error";
            message.setHeader("CamelHttpResponseCode", String(500));
            var properties = message.getProperties();
            var errore = properties.get("error");
        
            if(String(errore) === "noid")
            {
                //newBody.messageCode = String(200);
                //newBody.messageText = "The provided monitoring productId is unknown";
                newBody = [];
                message.setHeader("CamelHttpResponseCode", "200");

            }
            if(String(errore) === "nomonitoring")
            {
                newBody.messageCode = String(400);
                newBody.messageText = "No monitoring found";
                message.setHeader("CamelHttpResponseCode", "400");
                var result = properties.get("result");
                if(result !== null)
                {
                    result = JSON.parse(result);
                    //Rimuovo i monitorings
                    delete result.monitorings;
                    message.setHeader("CamelHttpResponseCode", "200");
                    message.setBody(JSON.stringify(result));
                    return message;
                }
            }
            
            
        }
        if(String(newBody.messageCode)[0] === "4")
            {
                var tmp = [];
                tmp.push(newBody);
                newBody = tmp;
            }
        message.setBody(JSON.stringify(newBody));


        
     return message;
}