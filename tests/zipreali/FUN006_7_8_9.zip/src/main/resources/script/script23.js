/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {

       //body
        var body = message.getBody();
        body = JSON.parse(body);
        if(body !== null)
        {
            var newBody = {
            "messageCode": "test",
            "messageText": "The provided monitoring productId is unknown"
            };
            
        var headers = message.getHeaders();
        var errorCode = parseInt(headers.get("CamelHttpResponseCode"));
        
        newBody.messageCode = errorCode;
        newBody.messageText = body.errors[0].details;        
        message.setBody(JSON.stringify(newBody));
        }
        
     return message;
}