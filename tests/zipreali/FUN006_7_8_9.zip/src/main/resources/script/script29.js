/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
       //body
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var body = JSON.parse(jsString);

    function replaceAll(str, cerca, sostituisci) {
        return str.split(cerca).join(sostituisci);
    }
      
    var productCodeResponse = replaceAll(body.product.name, " ", "").toUpperCase() + "FM";
    var properties = message.getProperties();
    var tmp_output = properties.get("tmp_output");
    tmp_output = JSON.parse(tmp_output);
    tmp_output[0].productCode = productCodeResponse;
    message.setBody(JSON.stringify(tmp_output));
    message.setProperty("Skyminder_Payload_Backup", JSON.stringify(tmp_output))
      
     return message;
}