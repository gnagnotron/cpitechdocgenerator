/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(java.nio.charset.StandardCharsets);

function processData(message) {
    
        var countryISOMapping = {
  AFG: "AF",
  ALA: "AX",
  ALB: "AL",
  DZA: "DZ",
  ASM: "AS",
  AND: "AD",
  AGO: "AO",
  AIA: "AI",
  ATA: "AQ",
  ATG: "AG",
  ARG: "AR",
  ARM: "AM",
  ABW: "AW",
  AUS: "AU",
  AUT: "AT",
  AZE: "AZ",
  BHS: "BS",
  BHR: "BH",
  BGD: "BD",
  BRB: "BB",
  BLR: "BY",
  BEL: "BE",
  BLZ: "BZ",
  BEN: "BJ",
  BMU: "BM",
  BTN: "BT",
  BOL: "BO",
  BIH: "BA",
  BWA: "BW",
  BVT: "BV",
  BRA: "BR",
  VGB: "VG",
  IOT: "IO",
  BRN: "BN",
  BGR: "BG",
  BFA: "BF",
  BDI: "BI",
  KHM: "KH",
  CMR: "CM",
  CAN: "CA",
  CPV: "CV",
  CYM: "KY",
  CUW: "CW",
  CAF: "CF",
  TCD: "TD",
  CHL: "CL",
  CHN: "CN",
  HKG: "HK",
  MAC: "MO",
  CXR: "CX",
  CCK: "CC",
  COL: "CO",
  COM: "KM",
  COG: "CG",
  COD: "CD",
  COK: "CK",
  CRI: "CR",
  CIV: "CI",
  HRV: "HR",
  CUB: "CU",
  CYP: "CY",
  CZE: "CZ",
  DNK: "DK",
  DJI: "DJ",
  DMA: "DM",
  DOM: "DO",
  ECU: "EC",
  EGY: "EG",
  SLV: "SV",
  GNQ: "GQ",
  ERI: "ER",
  EST: "EE",
  ETH: "ET",
  FLK: "FK",
  FRO: "FO",
  FJI: "FJ",
  FIN: "FI",
  FRA: "FR",
  GUF: "GF",
  PYF: "PF",
  ATF: "TF",
  GAB: "GA",
  GMB: "GM",
  GEO: "GE",
  DEU: "DE",
  GHA: "GH",
  GIB: "GI",
  GRC: "GR",
  GRL: "GL",
  GRD: "GD",
  GLP: "GP",
  GUM: "GU",
  GTM: "GT",
  GGY: "GG",
  GIN: "GN",
  GNB: "GW",
  GUY: "GY",
  HTI: "HT",
  HMD: "HM",
  VAT: "VA",
  HND: "HN",
  HUN: "HU",
  ISL: "IS",
  IND: "IN",
  IDN: "ID",
  IRN: "IR",
  IRQ: "IQ",
  IRL: "IE",
  IMN: "IM",
  ISR: "IL",
  ITA: "IT",
  JAM: "JM",
  JPN: "JP",
  JEY: "JE",
  JOR: "JO",
  KAZ: "KZ",
  KEN: "KE",
  KIR: "KI",
  PRK: "KP",
  KOR: "KR",
  KWT: "KW",
  KGZ: "KG",
  LAO: "LA",
  LVA: "LV",
  LBN: "LB",
  LSO: "LS",
  LBR: "LR",
  LBY: "LY",
  LIE: "LI",
  LTU: "LT",
  LUX: "LU",
  MKD: "MK",
  MDG: "MG",
  MWI: "MW",
  MYS: "MY",
  MDV: "MV",
  MLI: "ML",
  MLT: "MT",
  MHL: "MH",
  MTQ: "MQ",
  MRT: "MR",
  MUS: "MU",
  MYT: "YT",
  MEX: "MX",
  FSM: "FM",
  MDA: "MD",
  MCO: "MC",
  MNG: "MN",
  MNE: "ME",
  MSR: "MS",
  MAR: "MA",
  MOZ: "MZ",
  MMR: "MM",
  NAM: "NA",
  NRU: "NR",
  NPL: "NP",
  NLD: "NL",
  ANT: "AN",
  NCL: "NC",
  NZL: "NZ",
  NIC: "NI",
  NER: "NE",
  NGA: "NG",
  NIU: "NU",
  NFK: "NF",
  MNP: "MP",
  NOR: "NO",
  OMN: "OM",
  PAK: "PK",
  PLW: "PW",
  PSE: "PS",
  PAN: "PA",
  PNG: "PG",
  PRY: "PY",
  PER: "PE",
  PHL: "PH",
  PCN: "PN",
  POL: "PL",
  PRT: "PT",
  PRI: "PR",
  QAT: "QA",
  REU: "RE",
  ROU: "RO",
  RUS: "RU",
  RWA: "RW",
  BLM: "BL",
  SHN: "SH",
  KNA: "KN",
  LCA: "LC",
  MAF: "MF",
  SPM: "PM",
  VCT: "VC",
  WSM: "WS",
  SMR: "SM",
  STP: "ST",
  SAU: "SA",
  SEN: "SN",
  SRB: "RS",
  SYC: "SC",
  SLE: "SL",
  SGP: "SG",
  SVK: "SK",
  SVN: "SI",
  SLB: "SB",
  SOM: "SO",
  ZAF: "ZA",
  SGS: "GS",
  SSD: "SS",
  ESP: "ES",
  LKA: "LK",
  SDN: "SD",
  SUR: "SR",
  SJM: "SJ",
  SWZ: "SZ",
  SWE: "SE",
  SXM: "SX",
  CHE: "CH",
  SYR: "SY",
  TWN: "TW",
  TJK: "TJ",
  TZA: "TZ",
  THA: "TH",
  TLS: "TL",
  TGO: "TG",
  TKL: "TK",
  TON: "TO",
  TTO: "TT",
  TUN: "TN",
  TUR: "TR",
  TKM: "TM",
  TCA: "TC",
  TUV: "TV",
  UGA: "UG",
  UKR: "UA",
  ARE: "AE",
  GBR: "GB",
  USA: "US",
  UMI: "UM",
  URY: "UY",
  UZB: "UZ",
  VUT: "VU",
  VEN: "VE",
  VNM: "VN",
  VIR: "VI",
  WLF: "WF",
  ESH: "EH",
  YEM: "YE",
  ZMB: "ZM",
  ZWE: "ZW",
  XKX: "XK"
};
        // get body
        var body = message.getBody();
    	var inputStream = new java.io.InputStreamReader(body,StandardCharsets.UTF_8);
        var bufferedReader = new java.io.BufferedReader(inputStream);
        var inputLine = bufferedReader.readLine();
        bufferedReader.close();
        var jsString = String(inputLine);
        var payload = JSON.parse(jsString);
        var headers = message.getHeaders();

            //Dichiarazioni
        var company = {
            companyId: "",
            companyName: "",
            street: "",
            houseNumber: "",
            postalCode: "",
            city: "",
            region: "",
            registrationNumber: "",
            vatNumber: "",
            phoneNumber: "",
            legalFormCode: "",
            countryCodeISO: ""
        };
        var companyStatus, officeType, formattedAddress, email, website;
        var array = []; 
        officeType="Perchè non ci sono?";
        email = officeType;
        website = officeType;
        
        //Accedo agli elementi
        for(var i=0; i<payload.companies.length;i++)
        {
            company = {};
            //Aggiungo all'array i vari elementi
            for(var j=0; j<payload.companies[i].identifiers.length;j++)
            {
                //Controllo su type e prendo number
                if(payload.companies[i].identifiers[j].type === "SUPPLIER_ID"){
                    company.companyId = payload.companies[i].identifiers[j].number;
                }
                if(payload.companies[i].identifiers[j].type === "REGISTRATION_NUMBER"){
                    company.registrationNumber = payload.companies[i].identifiers[j].number;
                }
                if(payload.companies[i].identifiers[j].type === "VAT_NUMBER"){
                    company.vatNumber = payload.companies[i].identifiers[j].number;
                }
            }
            //In questo non serve il for
            company.companyName = payload.companies[i].name;
            
            if(payload.companies[i].contact !== undefined)
            {
                var stringPhones = "";
                
                for(var l = 0; l < payload.companies[i].contact.phones.length; l++)
                {
                    stringPhones = stringPhones + " " + payload.companies[i].contact.phones[l];
                }
                
                stringPhones = payload.companies[i].contact.phones.join("-");
                company.phoneNumber = stringPhones;
            }
            
            
            for(var z=0; z<payload.companies[i].addresses.length;z++)
            {
                company.street = payload.companies[i].addresses[z].street;
                company.houseNumber = payload.companies[i].addresses[z].houseNumber;
                company.postalCode = payload.companies[i].addresses[z].zipCode;
                company.city = payload.companies[i].addresses[z].city;
                company.region = payload.companies[i].addresses[z].regionCode;
                var iso2 = countryISOMapping[payload.companies[i].addresses[z].countryCode];
                company.countryCodeISO = iso2;
                //company.legalFormCode = ??
                formattedAddress = payload.companies[i].addresses[z].address;          
            }
            
            
            
            //Oggetto finale da mettere in payload
            var obj = {
                "company": company,
                //"companyStatus": companyStatus, 
                "formattedAddress": formattedAddress,
                //"officeType": officeType, 
                //"email": email, 
                //"website": website
            };
            array.push(obj);
        }
        
        
            
       
       message.setBody(JSON.stringify(array));
     return message;
}