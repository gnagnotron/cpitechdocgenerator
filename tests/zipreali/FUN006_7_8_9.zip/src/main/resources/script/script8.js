/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {

    // FUNCTIONS
    
    function formatDate(a, isDateTime)
    {
        a = a.slice(0,4) + "-" + a.slice(4,a.length);
        a = a.slice(0,7) + "-" + a.slice(7, a.length);
        if(isDateTime)
        {
            a = a.slice(0,13) + ":" + a.slice(13, a.length);
            a = a.slice(0,16) + ":" + a.slice(16, a.length); 
        }
        else
        {
            a = a.split("T")[0];
        }
        return a
        
    }
    

    var properties = message.getProperties();
    var companyId = properties.get("companyId");
    //body
    var body = message.getBody();
    var inputStream = new java.io.InputStreamReader(body);
    var bufferedReader = new java.io.BufferedReader(inputStream);
    var inputLine = bufferedReader.readLine();
    bufferedReader.close();
    var jsString = String(inputLine);
    var payload = JSON.parse(jsString);

 //Dichiaro la struttura
    var array = [];
    var arrayTmp = [];
    var obj = {};
     
    if (payload.items.length == 0 ) {
        
        array.messageCode = 400;
        array.messageText = "No monitoring found";
        message.setProperty("error", "nomonitoring");

        //throw array; 20250213 ML 
        return message;
    } 
     
    else 
     
    {
        for(var i = 0; i < payload.items.length; i++)
        {
            if(payload.items[i].company.identifiers.length !== 0)
            {
               if(String(payload.items[i].company.identifiers[0].number) == String(companyId))
                {
                    arrayTmp.push(payload.items[i]);
                } 
            }
            
        }
        
        var finalRegistered = 000000000000;
        var finalCompanyId = "";
        if(arrayTmp.length > 0)
        {
            for (var i = 0; i < arrayTmp.length; i++) {
                if (String(companyId) == String(arrayTmp[i].company.identifiers[0].number)) 
                {
                    var registeredAtVar = arrayTmp[i].registeredAt;
                    var days = registeredAtVar.split("T");
                    var time = days[1].split("Z");
                    var registeredAtVarSplit = days[0] + time[0];
    
                    if (parseInt(registeredAtVarSplit) > parseInt(finalRegistered)) 
                    {
                        finalRegistered = registeredAtVarSplit;
                        obj = {};
                        obj.activationId = String(arrayTmp[i].monitoringId);
                        obj.productCode = arrayTmp[i].skycode;
                        //obj.parentProductCode = arrayTmp[i].skycode;
                        obj.monitoringStartDate = arrayTmp[i].registeredAt;
                        obj.monitoringEndDate = arrayTmp[i].renewedAt;
                        //obj.activationStatusDescription = "";
                        //obj.activationStatus = arrayTmp[i].status;
                        obj.lastChangeDateTimeUTC = arrayTmp[i].updatedAt;
                        if (arrayTmp[i].status === "INACTIVE") 
                        {
                            obj.isUnlimitedMonitoring = false;
                            //obj.activationStatus = "CANCELLATION_REQUESTED";
                        } 
                        else 
                        {
                            obj.isUnlimitedMonitoring = true;
                            //obj.activationStatus = "ACTIVATED";
                        }
    
                    }
                }
    
            }
            

            array.push(obj);
            array[0].monitoringStartDate = formatDate(array[0].monitoringStartDate, false);
            array[0].monitoringEndDate = formatDate(array[0].monitoringEndDate, false);
            if(typeof(array[0].lastChangeDateTimeUTC) === "string" )
            {
                array[0].lastChangeDateTimeUTC = formatDate(array[0].lastChangeDateTimeUTC, true);
            }
            message.setProperty("tmp_output", JSON.stringify(array));
            message.setProperty("tmp_skycode", array[0].productCode);
        }
        else{
            var array = {};
            array.messageCode = 400;
            array.messageText = "The provided monitoring productId is unknown";
            message.setProperty("error", "noid");
        }
    }


    
    
 



    message.setBody(JSON.stringify(array));
    

    return message;
}


